# NLP-Based Sentiment Analysis of Product Reviews Using TF-IDF and Machine Learning

**Course Outcomes Addressed:** CO3, CO4
**Total Marks:** 7.5

---

## 1. Problem Statement

Online shoppers leave large volumes of free-text reviews about products, but manually
reading through all of them to gauge overall customer opinion does not scale. This project
builds an NLP system that automatically classifies a product review as **positive** or
**negative** based on its text content, using TF-IDF feature extraction combined with
supervised machine learning classifiers.

**Core question:** *Given the text of a product review, can a model reliably predict whether
the customer's sentiment is positive or negative?*

---

## 2. Objectives

1. Collect/prepare a labeled dataset of product reviews.
2. Preprocess raw review text into a clean, model-ready form.
3. Convert text into numeric features using TF-IDF (unigrams + bigrams).
4. Train and compare multiple classification algorithms (Naive Bayes, Logistic Regression,
   Linear SVM).
5. Evaluate the models using standard classification metrics.
6. Honestly test how well the trained model generalizes to review phrasing it has never
   seen before, rather than relying only on in-sample accuracy.
7. Identify limitations and propose realistic improvements.

---

## 3. Problem Relevance

- **Who benefits:** E-commerce platforms, sellers, and product managers who need a quick
  pulse on customer opinion without manually reading thousands of reviews.
- **Practical problem addressed:** Manual review triage is slow and does not scale; an
  automated sentiment classifier can flag negative reviews for follow-up, summarize
  overall satisfaction, and feed dashboards/analytics.
- **Why NLP is suitable:** Review sentiment is expressed in unstructured natural language
  (word choice, phrasing, negation), which structured/tabular methods cannot capture
  directly — NLP techniques are needed to convert this text into meaningful features.
- **Potential applications:** Review-moderation pipelines, customer-feedback dashboards,
  automatic alerting for negative feedback, product-quality monitoring.

---

## 4. Dataset

| Field | Description |
|---|---|
| **Name** | `product_reviews.csv` (self-created) + `external_test_reviews.csv` (self-created hold-out set) |
| **Source** | Self-created (see note below) |
| **Size** | 672 labeled reviews (training/in-domain test) + 20 hand-written hold-out reviews |
| **Fields** | `review_text` (string), `sentiment` (`positive` / `negative`) |
| **Target variable** | `sentiment` |
| **Number of classes** | 2 (binary classification), perfectly balanced (336 / 336) |

**Why self-created:** Public sentiment datasets (Amazon Fine Food Reviews, IMDB, Kaggle
sets) are normally hosted on Kaggle/Hugging Face, which were not reachable from the
development environment used for this project. The assignment explicitly permits
self-created datasets, so a synthetic-but-realistic dataset was generated programmatically
(`dataset/generate_dataset.py`) by combining 16 product types, 10 sentence templates per
class, and ~30 opinion "reasons" per class (sometimes combining two reasons per review to
increase lexical diversity). A fixed random seed (42) makes the dataset reproducible.

**Dataset limitations (acknowledged upfront):**
- Vocabulary is narrower than genuine human-written reviews.
- Because it is template-generated, an in-domain train/test split can look artificially
  easy for the model (see Section 7 — this is directly addressed via an external
  hold-out test).

To responsibly evaluate real-world generalization, a **second, independently hand-written
set of 20 reviews** (`external_test_reviews.csv`) was created using vocabulary and phrasing
that does **not** appear in the training templates (e.g. "useless", "ripoff", "garbage",
"mediocre", "underwhelmed"). This acts as a genuine out-of-domain test.

---

## 5. Methodology

```
Raw Review Text
      │
      ▼
Text Preprocessing (lowercasing, punctuation/digit removal,
                     stopword removal, lemmatization)
      │
      ▼
TF-IDF Vectorization (unigrams + bigrams, max_features=5000)
      │
      ▼
Classification Model (Naive Bayes / Logistic Regression / Linear SVM)
      │
      ▼
Prediction (positive / negative)
      │
      ▼
Evaluation (Accuracy, Precision, Recall, F1, Confusion Matrix,
            + external hold-out generalization check)
```

**Stage explanations:**
1. **Preprocessing** — Reviews are lowercased, non-alphabetic characters are stripped,
   text is tokenized on whitespace, English stopwords are removed, and remaining tokens
   are lemmatized (e.g., "running" → "running" is reduced toward its base form) to reduce
   vocabulary sparsity.
2. **TF-IDF Vectorization** — Term Frequency–Inverse Document Frequency weighs words by
   how distinctive they are to a document relative to the whole corpus. Bigrams (2-word
   phrases) are included so that phrases like "not good" are captured, partially handling
   negation.
3. **Classification** — Three classical ML algorithms suited to sparse, high-dimensional
   text features were trained and compared, rather than assuming one is best in advance.
4. **Evaluation** — Standard classification metrics were computed on a held-out 20% split,
   **and additionally** on a fully independent hand-written test set to check real
   generalization (see Section 7).

---

## 6. Implementation

- **Language:** Python 3
- **Libraries:** `pandas`, `scikit-learn`, `nltk`, `matplotlib`, `joblib`
- **NLP techniques:** Lemmatization, stopword removal, TF-IDF (unigram+bigram)
- **Algorithms:** Multinomial Naive Bayes, Logistic Regression, Linear SVM
- **Key implementation details:**
  - `TfidfVectorizer(ngram_range=(1,2), max_features=5000)`
  - `train_test_split(..., test_size=0.2, stratify=y, random_state=42)` for a
    reproducible, class-balanced split
  - The best-performing model (by F1-score) and the fitted vectorizer are persisted with
    `joblib` (`results/best_model.pkl`, `results/tfidf_vectorizer.pkl`) so predictions can
    be made on new text without retraining.

Full source code: `source_code.py`. Run with:
```bash
pip install -r requirements.txt
python source_code.py
```

---

## 7. Results

### 7.1 In-domain test set (20% split of the generated dataset, 135 reviews)

| Model | Accuracy | Precision | Recall | F1-score |
|---|---|---|---|---|
| Naive Bayes | 1.00 | 1.00 | 1.00 | 1.00 |
| Logistic Regression | 1.00 | 1.00 | 1.00 | 1.00 |
| Linear SVM | 1.00 | 1.00 | 1.00 | 1.00 |

All three models reach perfect scores on the in-domain test set. This is **expected and
somewhat artificial**: because the dataset is generated from a fixed set of templates and
opinion phrases, the training and in-domain test reviews share the same underlying
vocabulary, making the classification task easier than real-world sentiment analysis.
**This number alone should not be trusted as a measure of real-world performance** — see
7.2 below, which is why the external hold-out evaluation was built into this project from
the start.

![Model Comparison](../screenshots/model_comparison.png)

Confusion matrices for each model (all diagonal, confirming zero in-domain errors):

![Naive Bayes Confusion Matrix](../screenshots/confusion_matrix_Naive_Bayes.png)

### 7.2 External hold-out set (20 independently hand-written reviews)

Using the best in-domain model (Naive Bayes) on `external_test_reviews.csv`:

- **Accuracy: 0.80**
- **F1-score: 0.83**

| True | Predicted | Review |
|---|---|---|
| negative | **positive (wrong)** | "Completely useless, it broke on the very first day I used it." |
| negative | **positive (wrong)** | "Disgusting build quality, fell apart in my hands." |
| negative | **positive (wrong)** | "Extremely underwhelmed, expected much better for this price." |
| negative | **positive (wrong)** | "It's mediocre at best, wouldn't buy it again." |
| *(16 other reviews)* | correct | — |

![Generalization Gap](../screenshots/generalization_gap.png)

This 20-point accuracy drop between the in-domain test set and the external hold-out set
is the most important and honest result of this project (see Section 8 — Limitations).

---

## 8. Limitations

1. **Overfitting to template vocabulary:** The perfect in-domain score (Section 7.1) is
   inflated by the synthetic dataset's limited vocabulary and sentence structures — it does
   not reflect real-world performance.
2. **Poor generalization to unseen negative vocabulary:** All 4 misclassifications on the
   external set were **negative reviews predicted as positive**. The model failed to
   recognize negative-sentiment words it never saw in training (e.g., "useless",
   "disgusting", "underwhelmed", "mediocre") — it relies on surface-level word overlap with
   training data rather than a deeper understanding of sentiment.
3. **No explicit negation handling beyond bigrams:** Complex negation ("not as good as I
   hoped") or sarcasm is not reliably handled.
4. **Binary sentiment only:** Neutral or mixed-sentiment reviews are forced into
   positive/negative, which does not reflect real nuance.
5. **Small, synthetic dataset:** 672 reviews is small by NLP standards; real deployments
   would need thousands of genuinely human-written reviews.
6. **Domain-specific:** Trained only on generic product-review-style language; may not
   transfer to other domains (e.g., restaurant reviews, movie reviews) without retraining.

---

## 9. Future Scope

- Replace/augment the self-created dataset with a real dataset (e.g., Amazon Fine Food
  Reviews or IMDB) once such sources are accessible, to validate findings on real text.
- Use word embeddings (Word2Vec/GloVe) or contextual embeddings (BERT) instead of TF-IDF
  to better capture semantic similarity between unseen and seen negative/positive words.
- Add explicit negation-scope handling in preprocessing (e.g., tagging words following
  "not"/"never" until the next punctuation).
- Expand to 3-class sentiment (positive / neutral / negative) or a continuous sentiment
  score.
- Deploy as a simple web app (Flask/Streamlit) for interactive predictions.
- Perform error analysis with a much larger, more diverse hold-out set to better quantify
  real-world generalization.

---

## 10. Conclusion

This project developed an end-to-end NLP pipeline — preprocessing, TF-IDF feature
extraction, and classical ML classification (Naive Bayes, Logistic Regression, Linear
SVM) — to classify product reviews as positive or negative. All three models achieved
perfect scores on an in-domain test split, but a deliberately independent, hand-written
hold-out set revealed the true picture: **80% accuracy**, with all errors being negative
reviews that used vocabulary absent from training. This gap between in-domain and
out-of-domain performance was the key learning outcome of the project — it demonstrates
concretely why in-domain accuracy alone can be misleading, why dataset vocabulary
diversity matters, and why real-world NLP systems need to be stress-tested on genuinely
unseen language before being trusted. The project also produced a reusable, documented
pipeline (`source_code.py`) capable of retraining on a larger/real dataset with no
structural changes.
